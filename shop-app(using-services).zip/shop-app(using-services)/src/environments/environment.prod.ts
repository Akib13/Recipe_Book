export const environment = {
  production: true,
  firebaseAPIKey: 'AIzaSyDWJilks9qM3UqPp-L2tT-yqA_vqpGxruU'
};
